# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/jetson/yahboomcar_ws/devel/include".split(';') if "/home/jetson/yahboomcar_ws/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosmsg;rospy;dynamic_reconfigure;geometry_msgs;nav_msgs;tf".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "yahboomcar_bringup"
PROJECT_SPACE_DIR = "/home/jetson/yahboomcar_ws/devel"
PROJECT_VERSION = "0.0.0"
