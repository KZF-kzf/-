# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/jetson/yahboomcar_ws/src/yahboomcar_msgs/msg/Position.msg;/home/jetson/yahboomcar_ws/src/yahboomcar_msgs/msg/PointArray.msg;/home/jetson/yahboomcar_ws/src/yahboomcar_msgs/msg/Image_Msg.msg;/home/jetson/yahboomcar_ws/src/yahboomcar_msgs/msg/Target.msg;/home/jetson/yahboomcar_ws/src/yahboomcar_msgs/msg/TargetArray.msg"
services_str = ""
pkg_name = "yahboomcar_msgs"
dependencies_str = "std_msgs;geometry_msgs;actionlib_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "yahboomcar_msgs;/home/jetson/yahboomcar_ws/src/yahboomcar_msgs/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg;geometry_msgs;/opt/ros/melodic/share/geometry_msgs/cmake/../msg;actionlib_msgs;/opt/ros/melodic/share/actionlib_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
