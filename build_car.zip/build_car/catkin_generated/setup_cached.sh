#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export PWD='/home/jetson/yahboomcar_ws/build'
export ROS_PACKAGE_PATH='/home/jetson/software/library_ws/src:/home/jetson/yahboomcar_ws/src:/home/jetson/software/world_canvas/src:/opt/ros/melodic/share'