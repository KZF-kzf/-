# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = '/home/jetson/yahboomcar_ws/src'
whitelisted_packages = ''.split(';') if '' != '' else []
blacklisted_packages = ''.split(';') if '' != '' else []
underlay_workspaces = '/home/jetson/software/library_ws/devel;/home/jetson/yahboomcar_ws/devel;/home/jetson/software/world_canvas/devel;/opt/ros/melodic'.split(';') if '/home/jetson/software/library_ws/devel;/home/jetson/yahboomcar_ws/devel;/home/jetson/software/world_canvas/devel;/opt/ros/melodic' != '' else []
