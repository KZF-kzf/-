
"use strict";

let SetTarget = require('./SetTarget.js')

module.exports = {
  SetTarget: SetTarget,
};
