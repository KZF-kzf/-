
"use strict";

module.exports = {
  msg: require('./msg/_index.js'),
  srv: require('./srv/_index.js')
};
